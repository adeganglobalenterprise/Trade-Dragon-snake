import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

export enum AssetType {
  CRYPTO = 'CRYPTO',
  FOREX = 'FOREX',
  COMMODITY = 'COMMODITY',
  STOCK = 'STOCK',
}

export enum TradingStatus {
  ACTIVE = 'ACTIVE',
  MAINTENANCE = 'MAINTENANCE',
  DELISTED = 'DELISTED',
}

@Entity('trading_pairs')
@Index(['symbol'])
@Index(['assetType'])
export class TradingPair {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  symbol: string;

  @Column()
  name: string;

  @Column({ type: 'enum', enum: AssetType })
  assetType: AssetType;

  @Column({ type: 'enum', enum: TradingStatus, default: TradingStatus.ACTIVE })
  status: TradingStatus;

  @Column({ type: 'decimal', precision: 18, scale: 8 })
  currentPrice: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  previousPrice: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 0 })
  priceChange24h: number;

  @Column({ type: 'decimal', precision: 18, scale: 2 })
  volume24h: number;

  @Column({ type: 'decimal', precision: 18, scale: 2 })
  marketCap: number;

  @Column({ type: 'decimal', precision: 4, scale: 2, nullable: true })
  minLot: number;

  @Column({ type: 'decimal', precision: 4, scale: 2, nullable: true })
  maxLot: number;

  @Column({ type: 'int', nullable: true })
  maxLeverage: number;

  @Column({ type: 'decimal', precision: 5, scale: 4, nullable: true })
  spread: number;

  @Column({ type: 'decimal', precision: 5, scale: 4, default: 0.0001 })
  commission: number;

  @Column({ default: true })
  allowLong: boolean;

  @Column({ default: true })
  allowShort: boolean;

  @Column({ default: true })
  allowLimit: boolean;

  @Column({ default: true })
  allowMarket: boolean;

  @Column({ default: true })
  allowStop: boolean;

  @Column({ type: 'json', nullable: true })
  apiProviders: {
    binance?: boolean;
    coinbase?: boolean;
    kraken?: boolean;
    oanda?: boolean;
    fxcm?: boolean;
    alphaVantage?: boolean;
  };

  @Column({ type: 'json', nullable: true })
  baseCurrency: {
    code: string;
    name: string;
    symbol: string;
  };

  @Column({ type: 'json', nullable: true })
  quoteCurrency: {
    code: string;
    name: string;
    symbol: string;
  };

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}