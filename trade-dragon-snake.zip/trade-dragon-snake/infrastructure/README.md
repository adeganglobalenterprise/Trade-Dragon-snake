# Infrastructure Setup for Trade Dragon Snake Trade

This directory contains the infrastructure configuration for deploying the AI Trading Platform.

## Prerequisites

- Docker and Docker Compose installed
- AWS/GCP/Azure account (for production deployment)
- Domain name configured with SSL certificates

## Environment Variables

Create a `.env` file in the root directory:

```env
# Database
DB_USERNAME=postgres
DB_PASSWORD=your_secure_password
DB_NAME=trade_dragon_snake

# JWT
JWT_SECRET=your_jwt_secret_key

# Trading APIs
BINANCE_API_KEY=your_binance_api_key
BINANCE_API_SECRET=your_binance_api_secret
COINBASE_API_KEY=your_coinbase_api_key
COINBASE_API_SECRET=your_coinbase_api_secret
OANDA_API_KEY=your_oanda_api_key
OANDA_ACCOUNT_ID=your_oanda_account_id

# Monitoring
GRAFANA_PASSWORD=admin_secure_password

# Email (for notifications)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Payment Gateways
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_PUBLIC_KEY=your_stripe_public_key
PAYPAL_CLIENT_ID=your_paypal_client_id
PAYPAL_CLIENT_SECRET=your_paypal_client_secret
```

## Local Development

1. **Start all services:**
   ```bash
   docker-compose up -d
   ```

2. **View logs:**
   ```bash
   docker-compose logs -f
   ```

3. **Stop all services:**
   ```bash
   docker-compose down
   ```

4. **Stop all services and remove volumes:**
   ```bash
   docker-compose down -v
   ```

## Services

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:3001
- **API Documentation**: http://localhost:3001/api/docs
- **Grafana Dashboard**: http://localhost:3002 (admin/admin)
- **Prometheus**: http://localhost:9090

## Production Deployment

### AWS Deployment

1. **Create EC2 instances** with sufficient resources (recommended: t3.xlarge or larger)

2. **Set up RDS PostgreSQL**:
   ```bash
   aws rds create-db-instance \
     --db-instance-identifier trade-dragon-snake-db \
     --db-instance-class db.t3.medium \
     --engine postgres \
     --allocated-storage 100 \
     --master-username admin \
     --master-user-password your_secure_password
   ```

3. **Set up ElastiCache Redis**:
   ```bash
   aws elasticache create-cache-cluster \
     --cache-cluster-id trade-dragon-snake-redis \
     --cache-node-type cache.t3.medium \
     --engine redis \
     --num-cache-nodes 1
   ```

4. **Configure Load Balancer**:
   ```bash
   aws elbv2 create-load-balancer \
     --name trade-dragon-snake-lb \
     --subnets subnet-123 subnet-456 \
     --security-groups sg-123
   ```

5. **Deploy with Docker Compose**:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d
   ```

### Google Cloud Deployment

1. **Create GKE cluster**:
   ```bash
   gcloud container clusters create trade-dragon-snake \
     --num-nodes 3 \
     --machine-type n1-standard-4 \
     --zone us-central1-a
   ```

2. **Configure Cloud SQL**:
   ```bash
   gcloud sql instances create trade-dragon-snake-db \
     --tier db-n1-standard-2 \
     --region us-central1
   ```

3. **Deploy with Kubernetes**:
   ```bash
   kubectl apply -f k8s/
   ```

### Azure Deployment

1. **Create AKS cluster**:
   ```bash
   az aks create \
     --resource-group trade-dragon-snake-rg \
     --name trade-dragon-snake-aks \
     --node-count 3 \
     --node-vm-size Standard_D4s_v3
   ```

2. **Configure Azure Database for PostgreSQL**:
   ```bash
   az postgres server create \
     --name trade-dragon-snake-db \
     --resource-group trade-dragon-snake-rg \
     --location eastus \
     --admin-user admin \
     --admin-password your_secure_password
   ```

3. **Deploy with Helm**:
   ```bash
   helm install trade-dragon-snake ./helm-chart
   ```

## Monitoring

### Grafana Dashboard

Access: http://localhost:3002

Default credentials: admin/admin

Key dashboards:
- System Overview
- Trading Performance
- API Response Times
- Database Health
- Redis Cache Metrics

### Prometheus Metrics

Access: http://localhost:9090

Key metrics to monitor:
- `trading_orders_total`
- `trading_positions_open`
- `api_requests_total`
- `api_response_time_seconds`
- `database_connections_active`

## Security

1. **SSL/TLS Configuration**:
   - Place SSL certificates in `nginx/ssl/`
   - Update `nginx/nginx.conf` with your domain

2. **Firewall Rules**:
   - Only expose necessary ports (80, 443)
   - Restrict database access to internal network
   - Use security groups to limit access

3. **Rate Limiting**:
   - Configure Nginx rate limiting
   - Implement API rate limiting in backend

4. **DDoS Protection**:
   - Use CloudFlare or AWS Shield
   - Implement IP whitelisting for critical endpoints

## Backup Strategy

1. **Database Backups**:
   ```bash
   # Automated daily backups
   pg_dump -U postgres trade_dragon_snake > backup_$(date +%Y%m%d).sql
   
   # Restore from backup
   psql -U postgres trade_dragon_snake < backup_20240101.sql
   ```

2. **Redis Backups**:
   - Configure RDB snapshots
   - Enable AOF for durability

3. **Volume Backups**:
   - Use AWS EBS snapshots
   - Configure automated backup schedules

## Scaling

### Horizontal Scaling

1. **Add more backend instances**:
   ```bash
   docker-compose up -d --scale backend=3
   ```

2. **Configure load balancing**:
   - Nginx automatically distributes traffic
   - Configure session affinity if needed

### Vertical Scaling

1. **Increase instance size**:
   - Update docker-compose.yml
   - Redeploy services

2. **Database optimization**:
   - Add read replicas
   - Configure connection pooling

## Troubleshooting

### Common Issues

1. **Database connection errors**:
   ```bash
   docker-compose logs postgres
   docker-compose exec backend psql -U postgres -h postgres
   ```

2. **Redis connection errors**:
   ```bash
   docker-compose logs redis
   docker-compose exec redis redis-cli ping
   ```

3. **High memory usage**:
   - Check Docker stats: `docker stats`
   - Adjust resource limits in docker-compose.yml

4. **Slow API responses**:
   - Check backend logs: `docker-compose logs backend`
   - Monitor database queries
   - Review cache hit rates

## Support

For technical support:
- Email: support@tradedragonsnake.com
- Documentation: https://docs.tradedragonsnake.com
- Issues: https://github.com/tradedragonsnake/issues

## License

Owner: Olawale Abdul-Ganiyu Embade
© 2024 Trade Dragon Snake Trade