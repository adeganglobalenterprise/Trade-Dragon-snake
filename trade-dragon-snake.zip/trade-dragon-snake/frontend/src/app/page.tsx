'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function Home() {
  const router = useRouter()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-gradient-dark">
      {/* Navigation */}
      <nav className="bg-dragon-darker/90 backdrop-blur-lg border-b border-dragon-lighter sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-dragon-primary to-snake-emerald rounded-lg flex items-center justify-center animate-pulse-slow">
                <span className="text-2xl">🐉</span>
              </div>
              <div>
                <h1 className="text-xl font-bold dragon-gradient-text">Trade Dragon Snake Trade</h1>
                <p className="text-xs text-gray-400">AI-Powered Trading</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <Link href="/features" className="text-gray-300 hover:text-dragon-primary transition-colors">Features</Link>
              <Link href="/markets" className="text-gray-300 hover:text-dragon-primary transition-colors">Markets</Link>
              <Link href="/pricing" className="text-gray-300 hover:text-dragon-primary transition-colors">Pricing</Link>
              <Link href="/about" className="text-gray-300 hover:text-dragon-primary transition-colors">About</Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link
                href="/auth/login"
                className="px-4 py-2 text-sm font-medium text-dragon-primary hover:text-dragon-success transition-colors"
              >
                Login
              </Link>
              <Link
                href="/auth/register"
                className="dragon-button dragon-button-primary"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-dragon-primary/10 to-snake-emerald/10 opacity-50"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
          <div className="relative z-10 text-center">
            <div className="animate-float inline-block mb-6">
              <span className="text-8xl">🐉🐍</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="dragon-gradient-text">Trade Dragon Snake Trade</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Advanced AI-powered trading platform with real-time charts, automated trading bots, and multi-asset support including crypto, forex, and natural resources.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
              <Link
                href="/auth/register"
                className="dragon-button dragon-button-primary text-lg px-8 py-4 w-full sm:w-auto"
              >
                Start Trading Now
              </Link>
              <Link
                href="/demo"
                className="dragon-button bg-dragon-lighter hover:bg-dragon-light text-white text-lg px-8 py-4 w-full sm:w-auto"
              >
                Try Demo
              </Link>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              <div className="dragon-card">
                <div className="text-3xl font-bold dragon-gradient-text">500+</div>
                <div className="text-gray-400 text-sm">Trading Pairs</div>
              </div>
              <div className="dragon-card">
                <div className="text-3xl font-bold dragon-gradient-text">100M+</div>
                <div className="text-gray-400 text-sm">Daily Volume</div>
              </div>
              <div className="dragon-card">
                <div className="text-3xl font-bold dragon-gradient-text">50K+</div>
                <div className="text-gray-400 text-sm">Active Users</div>
              </div>
              <div className="dragon-card">
                <div className="text-3xl font-bold dragon-gradient-text">99.9%</div>
                <div className="text-gray-400 text-sm">Uptime</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-dragon-darker/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-16 dragon-gradient-text">
            Powerful Trading Features
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon="🤖"
              title="AI Trading Bot"
              description="Advanced AI algorithms analyze market trends and execute trades automatically with high precision."
            />
            <FeatureCard
              icon="📊"
              title="Real-Time Charts"
              description="Professional TradingView charts with multiple timeframes and technical indicators."
            />
            <FeatureCard
              icon="⚡"
              title="Lightning Fast"
              description="Execute trades in milliseconds with our low-latency trading engine."
            />
            <FeatureCard
              icon="💰"
              title="Multi-Asset Trading"
              description="Trade crypto, forex, commodities, and natural resources from a single platform."
            />
            <FeatureCard
              icon="🔒"
              title="Bank-Level Security"
              description="Your funds are protected with multi-layer security including 2FA and cold storage."
            />
            <FeatureCard
              icon="📱"
              title="Cross-Platform"
              description="Access your account on web, mobile (Android), and desktop (Windows)."
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="dragon-card border-glow">
            <h2 className="text-4xl font-bold mb-6 dragon-gradient-text">
              Ready to Start Trading?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Join thousands of traders who trust Trade Dragon Snake Trade for their investment needs.
            </p>
            <Link
              href="/auth/register"
              className="dragon-button dragon-button-primary text-lg px-8 py-4"
            >
              Create Free Account
            </Link>
            <p className="text-sm text-gray-400 mt-4">
              Minimum deposit: ₦100 • No hidden fees • 24/7 support
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-dragon-darker border-t border-dragon-lighter py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <span className="text-3xl">🐉</span>
                <span className="font-bold dragon-gradient-text">Trade Dragon Snake Trade</span>
              </div>
              <p className="text-gray-400 text-sm">
                Advanced AI-powered trading platform for the modern trader.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-white">Products</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><Link href="/markets" className="hover:text-dragon-primary">Markets</Link></li>
                <li><Link href="/trading" className="hover:text-dragon-primary">Trading</Link></li>
                <li><Link href="/ai-bot" className="hover:text-dragon-primary">AI Bot</Link></li>
                <li><Link href="/wallet" className="hover:text-dragon-primary">Wallet</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-white">Company</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><Link href="/about" className="hover:text-dragon-primary">About Us</Link></li>
                <li><Link href="/careers" className="hover:text-dragon-primary">Careers</Link></li>
                <li><Link href="/contact" className="hover:text-dragon-primary">Contact</Link></li>
                <li><Link href="/blog" className="hover:text-dragon-primary">Blog</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-white">Legal</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><Link href="/privacy" className="hover:text-dragon-primary">Privacy Policy</Link></li>
                <li><Link href="/terms" className="hover:text-dragon-primary">Terms of Service</Link></li>
                <li><Link href="/risk" className="hover:text-dragon-primary">Risk Disclaimer</Link></li>
                <li><Link href="/aml" className="hover:text-dragon-primary">AML Policy</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-dragon-lighter mt-8 pt-8 text-center text-gray-400 text-sm">
            <p>© 2024 Trade Dragon Snake Trade. Owner: Olawale Abdul-Ganiyu Embade. All rights reserved.</p>
            <p className="mt-2">
              Licensed and regulated for real trading operations.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon, title, description }: { icon: string, title: string, description: string }) {
  return (
    <div className="dragon-card hover:border-dragon-primary transition-all duration-300 transform hover:scale-105">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2 text-white">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  )
}