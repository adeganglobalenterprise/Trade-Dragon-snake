import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        dragon: {
          primary: '#10B981',      // Green for profits/growth
          secondary: '#EF4444',    // Red for losses/danger
          accent: '#8B5CF6',       // Purple for premium features
          dark: '#0F172A',         // Dark background
          darker: '#020617',       // Darkest background
          light: '#1E293B',        // Light dark for cards
          lighter: '#334155',      // Lighter dark for borders
          success: '#10B981',
          warning: '#F59E0B',
          danger: '#EF4444',
          info: '#3B82F6',
        },
        snake: {
          green: '#059669',
          emerald: '#10B981',
          teal: '#14B8A6',
        },
      },
      backgroundImage: {
        'gradient-dark': 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
        'gradient-card': 'linear-gradient(145deg, #1E293B 0%, #334155 100%)',
      },
      boxShadow: {
        'dragon': '0 4px 20px rgba(16, 185, 129, 0.3)',
        'snake': '0 4px 20px rgba(5, 150, 105, 0.3)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 3s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        glow: {
          '0%': { boxShadow: '0 0 5px #10B981, 0 0 10px #10B981' },
          '100%': { boxShadow: '0 0 20px #10B981, 0 0 30px #10B981' },
        },
      },
    },
  },
  plugins: [],
}

export default config