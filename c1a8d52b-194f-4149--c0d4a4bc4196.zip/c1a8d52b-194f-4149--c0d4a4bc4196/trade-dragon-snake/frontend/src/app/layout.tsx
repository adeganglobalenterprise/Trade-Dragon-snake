import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from './providers'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Trade Dragon Snake Trade - AI Trading Platform',
  description: 'Advanced AI-powered trading platform with real-time charts, automated trading, and multi-asset support. Owner: Olawale Abdul-Ganiyu Embade',
  keywords: 'trading, crypto, forex, AI trading, automated trading, investment',
  authors: [{ name: 'Olawale Abdul-Ganiyu Embade' }],
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
  themeColor: '#10B981',
  manifest: '/manifest.json',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/icon-192.png" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body className={inter.className}>
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  )
}