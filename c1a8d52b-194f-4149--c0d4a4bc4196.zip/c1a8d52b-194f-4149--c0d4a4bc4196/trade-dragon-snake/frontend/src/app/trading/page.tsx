'use client'

import { useState, useEffect } from 'react'
import { useQuery } from 'react-query'
import Link from 'next/link'
import { toast } from 'react-hot-toast'

interface TradingPair {
  id: string
  symbol: string
  name: string
  currentPrice: number
  priceChange24h: number
  volume24h: number
  assetType: string
}

export default function TradingPage() {
  const [selectedPair, setSelectedPair] = useState<TradingPair | null>(null)
  const [isLong, setIsLong] = useState(true)
  const [lotSize, setLotSize] = useState(0.01)
  const [leverage, setLeverage] = useState(10)
  const [stopLoss, setStopLoss] = useState<number | null>(null)
  const [takeProfit, setTakeProfit] = useState<number | null>(null)
  const [isAutoTrading, setIsAutoTrading] = useState(false)

  // Fetch trading pairs
  const { data: pairs, isLoading } = useQuery(
    'tradingPairs',
    async () => {
      const response = await fetch('/api/trading/pairs')
      if (!response.ok) throw new Error('Failed to fetch trading pairs')
      return response.json()
    },
    {
      refetchInterval: 5000, // Refresh every 5 seconds
    }
  )

  useEffect(() => {
    if (pairs && pairs.length > 0) {
      setSelectedPair(pairs[0])
    }
  }, [pairs])

  const calculatePositionSize = () => {
    if (!selectedPair) return 0
    return lotSize * selectedPair.currentPrice * leverage
  }

  const calculateMargin = () => {
    return calculatePositionSize() / leverage
  }

  const handleTrade = async () => {
    if (!selectedPair) return

    try {
      const response = await fetch('/api/trading/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({
          tradingPairId: selectedPair.id,
          side: isLong ? 'BUY' : 'SELL',
          orderType: 'MARKET',
          quantity: lotSize,
          leverage,
          stopLoss,
          takeProfit,
        }),
      })

      if (!response.ok) {
        throw new Error('Trade execution failed')
      }

      toast.success(`${isLong ? 'Buy' : 'Sell'} order executed successfully!`)
    } catch (error) {
      toast.error('Failed to execute trade. Please try again.')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-dark">
      {/* Header */}
      <nav className="bg-dragon-darker/90 backdrop-blur-lg border-b border-dragon-lighter sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Link href="/" className="text-3xl">🐉</Link>
              <span className="font-bold dragon-gradient-text">Trade Dragon Snake Trade</span>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/dashboard" className="text-gray-300 hover:text-dragon-primary transition-colors">Dashboard</Link>
              <Link href="/wallet" className="text-gray-300 hover:text-dragon-primary transition-colors">Wallet</Link>
              <Link href="/settings" className="text-gray-300 hover:text-dragon-primary transition-colors">Settings</Link>
              <button className="dragon-button dragon-button-primary">Logout</button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Left Sidebar - Trading Pairs */}
          <div className="lg:col-span-1">
            <div className="dragon-card sticky top-20">
              <h2 className="text-lg font-bold mb-4 text-white">Trading Pairs</h2>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {isLoading ? (
                  <div className="text-center py-8 text-gray-400">Loading...</div>
                ) : (
                  pairs?.map((pair: TradingPair) => (
                    <button
                      key={pair.id}
                      onClick={() => setSelectedPair(pair)}
                      className={`w-full p-3 rounded-lg text-left transition-all ${
                        selectedPair?.id === pair.id
                          ? 'bg-dragon-primary/20 border border-dragon-primary'
                          : 'bg-dragon-lighter/50 hover:bg-dragon-lighter/80'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="font-semibold text-white">{pair.symbol}</div>
                          <div className="text-xs text-gray-400">{pair.name}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-white">
                            ${pair.currentPrice.toFixed(8)}
                          </div>
                          <div className={`text-xs ${pair.priceChange24h >= 0 ? 'profit' : 'loss'}`}>
                            {pair.priceChange24h >= 0 ? '+' : ''}{pair.priceChange24h.toFixed(2)}%
                          </div>
                        </div>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Main Trading Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Chart */}
            <div className="dragon-card">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h2 className="text-2xl font-bold dragon-gradient-text">
                    {selectedPair?.symbol}
                  </h2>
                  <div className="flex items-center space-x-4 text-sm">
                    <span className="text-white">
                      ${selectedPair?.currentPrice.toFixed(8)}
                    </span>
                    <span className={selectedPair?.priceChange24h >= 0 ? 'profit' : 'loss'}>
                      {selectedPair?.priceChange24h >= 0 ? '+' : ''}{selectedPair?.priceChange24h.toFixed(2)}%
                    </span>
                  </div>
                </div>
                <div className="flex space-x-2">
                  {['1m', '5m', '15m', '1h', '4h', '1d'].map((timeframe) => (
                    <button
                      key={timeframe}
                      className="px-3 py-1 rounded bg-dragon-lighter hover:bg-dragon-light text-sm text-white transition-colors"
                    >
                      {timeframe}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* TradingView Chart Placeholder */}
              <div className="chart-container bg-dragon-dark rounded-lg flex items-center justify-center">
                <div className="text-center text-gray-400">
                  <div className="text-6xl mb-4">📊</div>
                  <p>TradingView Chart</p>
                  <p className="text-sm">Real-time price charts with technical indicators</p>
                </div>
              </div>
            </div>

            {/* Open Positions */}
            <div className="dragon-card">
              <h3 className="text-lg font-bold mb-4 text-white">Open Positions</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-gray-400 border-b border-dragon-lighter">
                      <th className="text-left py-2">Pair</th>
                      <th className="text-left py-2">Type</th>
                      <th className="text-left py-2">Size</th>
                      <th className="text-left py-2">Entry</th>
                      <th className="text-left py-2">Current</th>
                      <th className="text-left py-2">P&L</th>
                      <th className="text-left py-2">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-dragon-lighter/50">
                      <td className="py-3 text-white">BTC/USDT</td>
                      <td className="py-3 profit">LONG</td>
                      <td className="py-3 text-white">0.5</td>
                      <td className="py-3 text-white">$42,500</td>
                      <td className="py-3 text-white">$43,200</td>
                      <td className="py-3 profit">+$350.00</td>
                      <td className="py-3">
                        <button className="dragon-button dragon-button-secondary text-xs px-3 py-1">
                          Close
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Right Sidebar - Trade Execution */}
          <div className="lg:col-span-1">
            <div className="dragon-card sticky top-20">
              <h2 className="text-lg font-bold mb-4 text-white">Place Order</h2>
              
              {/* Long/Short Toggle */}
              <div className="flex mb-6 bg-dragon-dark rounded-lg p-1">
                <button
                  onClick={() => setIsLong(true)}
                  className={`flex-1 py-2 rounded-lg font-semibold transition-all ${
                    isLong
                      ? 'bg-dragon-primary text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Long
                </button>
                <button
                  onClick={() => setIsLong(false)}
                  className={`flex-1 py-2 rounded-lg font-semibold transition-all ${
                    !isLong
                      ? 'bg-dragon-secondary text-white'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  Short
                </button>
              </div>

              {/* Order Type */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Order Type
                </label>
                <select className="dragon-input w-full">
                  <option>Market</option>
                  <option>Limit</option>
                  <option>Stop</option>
                </select>
              </div>

              {/* Lot Size */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Lot Size (0.01 - 50)
                </label>
                <input
                  type="number"
                  min="0.01"
                  max="50"
                  step="0.01"
                  value={lotSize}
                  onChange={(e) => setLotSize(parseFloat(e.target.value))}
                  className="dragon-input w-full"
                />
                <div className="flex justify-between mt-2 text-xs text-gray-400">
                  {[0.01, 0.1, 1, 10].map((size) => (
                    <button
                      key={size}
                      onClick={() => setLotSize(size)}
                      className="px-2 py-1 bg-dragon-lighter rounded hover:bg-dragon-light transition-colors text-white"
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Leverage */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Leverage: {leverage}x
                </label>
                <input
                  type="range"
                  min="1"
                  max="100"
                  value={leverage}
                  onChange={(e) => setLeverage(parseInt(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>1x</span>
                  <span>50x</span>
                  <span>100x</span>
                </div>
              </div>

              {/* Stop Loss */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Stop Loss (Optional)
                </label>
                <input
                  type="number"
                  value={stopLoss || ''}
                  onChange={(e) => setStopLoss(e.target.value ? parseFloat(e.target.value) : null)}
                  placeholder="Price"
                  className="dragon-input w-full"
                />
              </div>

              {/* Take Profit */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Take Profit (Optional)
                </label>
                <input
                  type="number"
                  value={takeProfit || ''}
                  onChange={(e) => setTakeProfit(e.target.value ? parseFloat(e.target.value) : null)}
                  placeholder="Price"
                  className="dragon-input w-full"
                />
              </div>

              {/* Position Summary */}
              <div className="bg-dragon-dark rounded-lg p-4 mb-6 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Position Value</span>
                  <span className="text-white">${calculatePositionSize().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Margin Required</span>
                  <span className="text-white">${calculateMargin().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Fees</span>
                  <span className="text-white">${(calculatePositionSize() * 0.0004).toFixed(2)}</span>
                </div>
              </div>

              {/* AI Trading Bot Toggle */}
              <div className="flex items-center justify-between mb-6 p-3 bg-dragon-dark rounded-lg">
                <div>
                  <div className="font-semibold text-white">AI Trading Bot</div>
                  <div className="text-xs text-gray-400">Auto-execute trades</div>
                </div>
                <button
                  onClick={() => setIsAutoTrading(!isAutoTrading)}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    isAutoTrading ? 'bg-dragon-primary' : 'bg-dragon-lighter'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      isAutoTrading ? 'translate-x-6' : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>

              {/* Execute Trade Button */}
              <button
                onClick={handleTrade}
                className={`dragon-button w-full text-lg py-4 ${
                  isLong ? 'dragon-button-primary' : 'dragon-button-secondary'
                }`}
              >
                {isLong ? '🟢 Buy / Long' : '🔴 Sell / Short'}
              </button>

              <p className="text-xs text-gray-400 text-center mt-4">
                Trading involves risk. Only trade with funds you can afford to lose.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}