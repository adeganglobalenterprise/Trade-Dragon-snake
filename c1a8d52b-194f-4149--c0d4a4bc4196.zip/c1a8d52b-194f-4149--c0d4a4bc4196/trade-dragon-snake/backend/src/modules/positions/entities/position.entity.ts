import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { TradingPair } from '../../trading/entities/trading-pair.entity';
import { Order } from '../../orders/entities/order.entity';

export enum PositionType {
  LONG = 'LONG',
  SHORT = 'SHORT',
}

export enum PositionStatus {
  OPEN = 'OPEN',
  CLOSED = 'CLOSED',
  LIQUIDATED = 'LIQUIDATED',
}

@Entity('positions')
@Index(['userId'])
@Index(['tradingPairId'])
@Index(['status'])
@Index(['positionType'])
export class Position {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  positionId: string;

  @Column('uuid')
  userId: string;

  @Column('uuid')
  tradingPairId: string;

  @Column('uuid', { nullable: true })
  orderId: string;

  @Column({ type: 'enum', enum: PositionType })
  positionType: PositionType;

  @Column({ type: 'enum', enum: PositionStatus, default: PositionStatus.OPEN })
  status: PositionStatus;

  @Column({ type: 'decimal', precision: 18, scale: 8 })
  entryPrice: number;

  @Column({ type: 'decimal', precision: 18, scale: 8 })
  currentPrice: number;

  @Column({ type: 'decimal', precision: 18, scale: 8 })
  quantity: number;

  @Column({ type: 'decimal', precision: 18, scale: 2 })
  positionValue: number;

  @Column({ type: 'decimal', precision: 18, scale: 2 })
  margin: number;

  @Column({ type: 'decimal', precision: 4, scale: 2, default: 1 })
  leverage: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  unrealizedPnL: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 0 })
  unrealizedPnLPercent: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  realizedPnL: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  stopLoss: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  takeProfit: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  liquidationPrice: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  commission: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, default: 0 })
  fundingRate: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  fundingFees: number;

  @Column({ type: 'timestamp', nullable: true })
  openedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  closedAt: Date;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  maxProfit: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  maxLoss: number;

  @Column({ type: 'json', nullable: true })
  tradingBot: {
    enabled: boolean;
    botId: string;
    strategy: string;
    autoCloseEnabled: boolean;
    autoCloseProfit: number;
  };

  @Column({ type: 'json', nullable: true })
  indicators: {
    rsi?: number;
    macd?: number;
    ma20?: number;
    ma50?: number;
    ema?: number;
    bb?: {
      upper: number;
      middle: number;
      lower: number;
    };
  };

  @Column({ type: 'json', nullable: true })
  aiSignals: {
    buySignal: boolean;
    sellSignal: boolean;
    confidence: number;
    timestamp: Date;
  };

  @Column({ type: 'text', nullable: true })
  notes: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Relations
  @ManyToOne(() => User, user => user.positions)
  @JoinColumn({ name: 'userId' })
  user: User;

  @ManyToOne(() => TradingPair)
  @JoinColumn({ name: 'tradingPairId' })
  tradingPair: TradingPair;

  @ManyToOne(() => Order)
  @JoinColumn({ name: 'orderId' })
  order: Order;
}