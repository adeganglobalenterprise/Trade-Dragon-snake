import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Wallet } from '../../wallet/entities/wallet.entity';

export enum TransactionType {
  DEPOSIT = 'DEPOSIT',
  WITHDRAWAL = 'WITHDRAWAL',
  TRADE = 'TRADE',
  TRANSFER = 'TRANSFER',
  FEE = 'FEE',
  REFUND = 'REFUND',
  PROFIT = 'PROFIT',
  LOSS = 'LOSS',
}

export enum TransactionStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED',
}

export enum PaymentMethod {
  DEBIT_CARD = 'DEBIT_CARD',
  CREDIT_CARD = 'CREDIT_CARD',
  PAYPAL = 'PAYPAL',
  CRYPTO = 'CRYPTO',
  BANK_TRANSFER = 'BANK_TRANSFER',
  LOCAL_BANK = 'LOCAL_BANK',
  MICROFINANCE = 'MICROFINANCE',
  COMMERCIAL_BANK = 'COMMERCIAL_BANK',
  GIFT_CARD = 'GIFT_CARD',
}

@Entity('transactions')
@Index(['userId'])
@Index(['walletId'])
@Index(['status'])
@Index(['transactionType'])
export class Transaction {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  transactionId: string;

  @Column('uuid')
  userId: string;

  @Column('uuid')
  walletId: string;

  @Column({ type: 'enum', enum: TransactionType })
  transactionType: TransactionType;

  @Column({ type: 'enum', enum: TransactionStatus, default: TransactionStatus.PENDING })
  status: TransactionStatus;

  @Column({ type: 'enum', enum: PaymentMethod })
  paymentMethod: PaymentMethod;

  @Column({ type: 'decimal', precision: 18, scale: 2 })
  amount: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  fee: number;

  @Column({ type: 'decimal', precision: 18, scale: 2 })
  totalAmount: number;

  @Column()
  currency: string;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  exchangeRate: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, nullable: true })
  convertedAmount: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, nullable: true })
  balanceBefore: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, nullable: true })
  balanceAfter: number;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'text', nullable: true })
  reference: string;

  @Column({ type: 'text', nullable: true })
  transactionHash: string;

  @Column({ type: 'text', nullable: true })
  gatewayTransactionId: string;

  @Column({ type: 'json', nullable: true })
  paymentDetails: {
    cardLast4?: string;
    cardBrand?: string;
    bankName?: string;
    accountNumber?: string;
    cryptoAddress?: string;
    cryptoNetwork?: string;
    paypalEmail?: string;
    giftCardCode?: string;
  };

  @Column({ type: 'timestamp', nullable: true })
  processedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  completedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  failedAt: Date;

  @Column({ type: 'text', nullable: true })
  failureReason: string;

  @Column({ type: 'json', nullable: true })
  metadata: {
    ipAddress: string;
    userAgent: string;
    kycVerified: boolean;
    amlChecked: boolean;
    source: 'WEB' | 'MOBILE' | 'API' | 'BOT';
  };

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Relations
  @ManyToOne(() => User, user => user.transactions)
  @JoinColumn({ name: 'userId' })
  user: User;

  @ManyToOne(() => Wallet, wallet => wallet.transactions)
  @JoinColumn({ name: 'walletId' })
  wallet: Wallet;
}