import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

export enum SignalType {
  BUY = 'BUY',
  SELL = 'SELL',
  HOLD = 'HOLD',
}

export enum SignalStrength {
  WEAK = 'WEAK',
  MODERATE = 'MODERATE',
  STRONG = 'STRONG',
  VERY_STRONG = 'VERY_STRONG',
}

export enum SignalSource {
  MOVING_AVERAGE = 'MOVING_AVERAGE',
  RSI = 'RSI',
  MACD = 'MACD',
  BREAKOUT = 'BREAKOUT',
  VOLUME = 'VOLUME',
  TREND_FOLLOWING = 'TREND_FOLLOWING',
  MEAN_REVERSION = 'MEAN_REVERSION',
  AI_MODEL = 'AI_MODEL',
  COMPOSITE = 'COMPOSITE',
}

export enum SignalStatus {
  ACTIVE = 'ACTIVE',
  EXECUTED = 'EXECUTED',
  EXPIRED = 'EXPIRED',
  CANCELLED = 'CANCELLED',
}

@Entity('signals')
@Index(['tradingPairId'])
@Index(['signalType'])
@Index(['status'])
@Index(['createdAt'])
export class Signal {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  signalId: string;

  @Column('uuid')
  tradingPairId: string;

  @Column()
  symbol: string;

  @Column({ type: 'enum', enum: SignalType })
  signalType: SignalType;

  @Column({ type: 'enum', enum: SignalStrength })
  strength: SignalStrength;

  @Column({ type: 'enum', enum: SignalSource })
  source: SignalSource;

  @Column({ type: 'enum', enum: SignalStatus, default: SignalStatus.ACTIVE })
  status: SignalStatus;

  @Column({ type: 'decimal', precision: 18, scale: 8 })
  entryPrice: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  targetPrice: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  stopLoss: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 0 })
  confidence: number;

  @Column({ type: 'decimal', precision: 18, scale: 8 })
  currentPrice: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 0 })
  priceChangePercent: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  targetProfitPercent: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  riskRewardRatio: number;

  @Column({ type: 'json', nullable: true })
  indicators: {
    rsi?: number;
    macd?: {
      value: number;
      signal: number;
      histogram: number;
    };
    movingAverages?: {
      ma20: number;
      ma50: number;
      ma200: number;
    };
    bollingerBands?: {
      upper: number;
      middle: number;
      lower: number;
    };
    volume?: number;
    volumeChangePercent?: number;
  };

  @Column({ type: 'json', nullable: true })
  aiAnalysis: {
    sentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
    predictedDirection: 'UP' | 'DOWN' | 'SIDEWAYS';
    timeFrame: string;
    modelConfidence: number;
    features: string[];
  };

  @Column({ type: 'timestamp', nullable: true })
  executedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  expiresAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  targetReachedAt: Date;

  @Column({ type: 'decimal', precision: 18, scale: 8, nullable: true })
  actualProfit: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, nullable: true })
  actualProfitPercent: number;

  @Column({ type: 'int', default: 0 })
  usersNotified: number;

  @Column({ type: 'int', default: 0 })
  usersActed: number;

  @Column({ default: false })
  isAutoTradeEnabled: boolean;

  @Column({ type: 'json', nullable: true })
  metadata: {
    timeframe: string;
    algorithm: string;
    parameters: any;
    backtestResults?: {
      winRate: number;
      avgProfit: number;
      avgLoss: number;
      totalTrades: number;
    };
  };

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}