import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
  Index,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { Transaction } from '../../payments/entities/transaction.entity';

export enum WalletType {
  FIAT = 'FIAT',
  CRYPTO = 'CRYPTO',
}

export enum WalletStatus {
  ACTIVE = 'ACTIVE',
  FROZEN = 'FROZEN',
  CLOSED = 'CLOSED',
}

@Entity('wallets')
@Index(['userId'])
@Index(['currency'])
@Index(['walletType'])
export class Wallet {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true })
  walletAddress: string;

  @Column('uuid')
  userId: string;

  @Column({ type: 'enum', enum: WalletType })
  walletType: WalletType;

  @Column()
  currency: string;

  @Column({ type: 'enum', enum: WalletStatus, default: WalletStatus.ACTIVE })
  status: WalletStatus;

  @Column({ type: 'decimal', precision: 18, scale: 8, default: 0 })
  balance: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, default: 0 })
  lockedBalance: number;

  @Column({ type: 'decimal', precision: 18, scale: 8, default: 0 })
  availableBalance: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  totalDeposits: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  totalWithdrawals: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  totalProfit: number;

  @Column({ type: 'decimal', precision: 18, scale: 2, default: 0 })
  totalLoss: number;

  @Column({ nullable: true })
  bankName: string;

  @Column({ nullable: true })
  accountNumber: string;

  @Column({ nullable: true })
  accountName: string;

  @Column({ nullable: true })
  routingNumber: string;

  @Column({ nullable: true })
  swiftCode: string;

  @Column({ nullable: true })
  iban: string;

  @Column({ nullable: true })
  cryptoAddress: string;

  @Column({ nullable: true })
  paypalEmail: string;

  @Column({ nullable: true })
  giftCardCode: string;

  @Column({ default: true })
  isDefault: boolean;

  @Column({ type: 'json', nullable: true })
  metadata: {
    provider: 'STRIPE' | 'PAYPAL' | 'BINANCE' | 'COINBASE' | 'LOCAL_BANK';
    providerId?: string;
    lastUsed?: Date;
    verified?: boolean;
  };

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Relations
  @ManyToOne(() => User, user => user.wallets)
  @JoinColumn({ name: 'userId' })
  user: User;

  @OneToMany(() => Transaction, transaction => transaction.wallet)
  transactions: Transaction[];
}